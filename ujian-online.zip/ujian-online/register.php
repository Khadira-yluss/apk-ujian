<?php
session_start();
include 'koneksi.php';

$message = '';
if (isset($_POST['nama'], $_POST['email'], $_POST['password'])) {
    $nama = trim($_POST['nama']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    // Validasi sederhana
    if ($nama && $email && $password) {
        // Cek email sudah terdaftar
        $stmt = mysqli_prepare($koneksi, "SELECT id FROM users WHERE email=?");
        mysqli_stmt_bind_param($stmt, "s", $email);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_store_result($stmt);
        if (mysqli_stmt_num_rows($stmt) > 0) {
            $message = "Email sudah terdaftar!";
        } else {
            // Simpan user baru
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $role = 'siswa';
            $stmt2 = mysqli_prepare($koneksi, "INSERT INTO users (nama, email, password, role) VALUES (?, ?, ?, ?)");
            mysqli_stmt_bind_param($stmt2, "ssss", $nama, $email, $hash, $role);
            if (mysqli_stmt_execute($stmt2)) {
                $message = "Pendaftaran berhasil! Silakan login.";
            } else {
                $message = "Gagal mendaftar. Silakan coba lagi.";
            }
            mysqli_stmt_close($stmt2);
        }
        mysqli_stmt_close($stmt);
    } else {
        $message = "Semua field wajib diisi!";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Daftar Akun Siswa</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body class="register-page">
    <div class="form-container">
        <h2>Daftar Akun Siswa</h2>
        <?php if ($message): ?>
            <div class="alert"><?= htmlspecialchars($message) ?></div>
        <?php endif; ?>
        <form method="post">
            <input type="text" name="nama" placeholder="Nama Lengkap" required>
            <input type="email" name="email" placeholder="Email Aktif" required>
            <input type="password" name="password" placeholder="Kata Sandi" required>
            <button type="submit">Daftar Sekarang</button>
        </form>
        <p class="bottom-link">Sudah punya akun? <a href="index.php">Masuk di sini</a></p>
    </div>
</body>
</html>
