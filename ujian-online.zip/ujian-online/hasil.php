<?php
session_start();
include 'koneksi.php';

// Pastikan user login
if (!isset($_SESSION['user']) || !isset($_SESSION['user']['id_user'])) {
    header("Location: login.php");
    exit();
}

// Ambil ID user dari session
$id_user = intval($_SESSION['user']['id_user']);

// Ambil semua soal
$query = mysqli_query($koneksi, "SELECT * FROM soal");
if (!$query) {
    die("Gagal mengambil data soal: " . mysqli_error($koneksi));
}
$total_soal = mysqli_num_rows($query);

$jawaban_benar = 0;

// Cek jawaban user
while ($data = mysqli_fetch_array($query)) {
    $id_soal = $data['id_soal'];
    $jawaban_user = isset($_POST['jawaban'][$id_soal]) ? strtoupper(trim($_POST['jawaban'][$id_soal])) : '';

    if ($jawaban_user === strtoupper($data['jawaban_benar'])) {
        $jawaban_benar++;
    }
}

// Hitung nilai
$nilai = $total_soal > 0 ? ($jawaban_benar / $total_soal) * 100 : 0;

// Simpan ke database
$stmt = mysqli_prepare($koneksi, "INSERT INTO hasil_ujian (id_user, jumlah_benar, total_soal, nilai) VALUES (?, ?, ?, ?)");
if ($stmt) {
    mysqli_stmt_bind_param($stmt, "iiid", $id_user, $jawaban_benar, $total_soal, $nilai);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
}
mysqli_close($koneksi);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Hasil Ujian</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="hasil-container">
        <h2>Hasil Ujian</h2>
        <p><strong>Total Soal:</strong> <?= $total_soal ?></p>
        <p><strong>Jawaban Benar:</strong> <?= $jawaban_benar ?></p>
        <p><strong>Nilai Akhir:</strong> <?= round($nilai) ?></p>
        <a class="btn-dashboard" href="dashboard.php">Kembali ke Dashboard</a>
    </div>
</body>
</html>
