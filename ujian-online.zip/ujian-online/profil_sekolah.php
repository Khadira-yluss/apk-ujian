<?php
session_start();
if (!isset($_SESSION['user']) || !isset($_SESSION['user']['role']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

include 'koneksi.php';
$result = mysqli_query($koneksi, "SELECT * FROM profil_sekolah LIMIT 1");
if (!$result) {
    $profil = false;
} else {
    $profil = mysqli_fetch_assoc($result);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <title>Profil Sekolah - UjianKu</title>
  <link rel="stylesheet" href="css/style.css" />
</head>
<body>
  <header class="header">
    <h1>Profil Sekolah</h1>
    <nav>
      <a href="dashboard.php">Dashboard</a>
      <a href="profil_sekolah.php" class="active">Profil Sekolah</a>
      <a href="kelola_tes.php">Tes</a>
      <a href="data_user.php">User</a>
      <a href="logout.php">Logout</a>
    </nav>
  </header>
  <main class="container">
    <?php if ($profil): ?>
      <div class="card">
        <h2><?= htmlspecialchars($profil['nama_sekolah'] ?? '') ?></h2>
        <p><strong>Alamat:</strong> <?= htmlspecialchars($profil['alamat'] ?? '') ?></p>
        <p><strong>Telepon:</strong> <?= htmlspecialchars($profil['telepon'] ?? '') ?></p>
        <p><strong>Email:</strong> <?= htmlspecialchars($profil['email'] ?? '') ?></p>
      </div>
    <?php else: ?>
      <p>Data profil sekolah belum tersedia.</p>
    <?php endif; ?>
  </main>
  <footer class="footer">
    <p>&copy; <?= date('Y') ?> UjianKu</p>
  </footer>
</body>
</html>
