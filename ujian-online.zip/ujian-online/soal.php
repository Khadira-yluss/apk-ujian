<?php
session_start();
require 'koneksi.php';

// Cek login (konsisten dengan session yang lain)
if (!isset($_SESSION['user']) || !isset($_SESSION['user']['id_user'])) {
    header("Location: login.php");
    exit;
}

$id_user = $_SESSION['user']['id_user'];

// Ambil soal
$soal = mysqli_query($koneksi, "SELECT * FROM soal ORDER BY RAND() LIMIT 10"); // ambil 10 soal acak
if (!$soal) {
    die("Gagal mengambil soal: " . mysqli_error($koneksi));
}
$nomor = 1;
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Soal Ujian</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        body {
            background: linear-gradient(to right, #5949ff, #7152f6);
            font-family: 'Segoe UI', sans-serif;
            color: #fff;
            padding: 20px;
        }
        .soal-container {
            max-width: 800px;
            margin: auto;
            background: #ffffff;
            color: #333;
            border-radius: 16px;
            padding: 2rem;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
        }
        .soal-item {
            margin-bottom: 2rem;
        }
        .soal-item h4 {
            margin-bottom: 1rem;
            font-size: 1.2rem;
        }
        .pilihan label {
            display: block;
            background: #f2f2f2;
            padding: 0.75rem 1rem;
            margin-bottom: 0.5rem;
            border-radius: 10px;
            cursor: pointer;
            transition: 0.3s;
        }
        .pilihan input {
            display: none;
        }
        .pilihan input:checked + label {
            background: #4a38f0;
            color: white;
            font-weight: bold;
        }
        .btn-submit {
            background: #4a38f0;
            color: white;
            padding: 0.75rem 2rem;
            border: none;
            border-radius: 12px;
            font-size: 1rem;
            cursor: pointer;
            margin-top: 1.5rem;
            transition: 0.3s;
        }
        .btn-submit:hover {
            background: #372dd0;
        }
    </style>
</head>
<body>
    <div class="soal-container">
        <h2 style="text-align: center;">📝 Ujian Online - UjianKu</h2>
        <form action="hasil.php" method="post">
            <?php while ($data = mysqli_fetch_array($soal)) : ?>
                <div class="soal-item">
                    <h4><?= $nomor . ". " . htmlspecialchars($data['pertanyaan'] ?? '') ?></h4>
                    <div class="pilihan">
                        <input type="radio" name="jawaban[<?= $data['id_soal'] ?>]" id="a<?= $data['id_soal'] ?>" value="A">
                        <label for="a<?= $data['id_soal'] ?>"><?= htmlspecialchars($data['pilihan_a'] ?? '') ?></label>

                        <input type="radio" name="jawaban[<?= $data['id_soal'] ?>]" id="b<?= $data['id_soal'] ?>" value="B">
                        <label for="b<?= $data['id_soal'] ?>"><?= htmlspecialchars($data['pilihan_b'] ?? '') ?></label>

                        <input type="radio" name="jawaban[<?= $data['id_soal'] ?>]" id="c<?= $data['id_soal'] ?>" value="C">
                        <label for="c<?= $data['id_soal'] ?>"><?= htmlspecialchars($data['pilihan_c'] ?? '') ?></label>

                        <input type="radio" name="jawaban[<?= $data['id_soal'] ?>]" id="d<?= $data['id_soal'] ?>" value="D">
                        <label for="d<?= $data['id_soal'] ?>"><?= htmlspecialchars($data['pilihan_d'] ?? '') ?></label>
                    </div>
                </div>
                <?php $nomor++; ?>
            <?php endwhile; ?>
            <button type="submit" class="btn-submit">Selesai Ujian</button>
        </form>
    </div>
</body>
</html>

