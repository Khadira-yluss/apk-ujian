<?php
// koneksi.php

if (!isset($koneksi)) {
    $host = "localhost";      // atau 127.0.0.1
    $user = "root";           // default username MySQL di Laragon
    $pass = "";               // defaultnya kosong
    $db   = "ujian_online";   // sesuaikan dengan nama database kamu

    $koneksi = mysqli_connect($host, $user, $pass, $db);

    // Cek koneksi
    if (!$koneksi) {
        die("Koneksi ke database gagal: " . mysqli_connect_error());
    }
}
?>
