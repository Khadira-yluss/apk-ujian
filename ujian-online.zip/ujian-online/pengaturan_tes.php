<?php
session_start();
// Cek apakah user sudah login dan merupakan admin
if (!isset($_SESSION['user_level']) || $_SESSION['user_level'] !== 'admin') {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Pengaturan Soal - UjianKu</title>
    <link rel="stylesheet" href="css/style.css" />
</head>
<body class="site-wrapper">
    <header>
        <div class="container">
            <h1>UjianKu</h1>
            <nav>
                <a href="dashboard.php">Dashboard</a>
                <a href="pengaturan_soal.php" class="active">Pengaturan Soal</a>
                <a href="pengaturan_tes.php">Tes Ujian</a>
                <a href="profil_sekolah.php">Profil Sekolah</a>
                <a href="logout.php" class="logout-btn">Keluar</a>
            </nav>
        </div>
    </header>

    <main>
        <section class="content">
            <div class="container">
                <h2>Pengaturan Soal</h2>
                <form action="proses_soal.php" method="POST" class="form-card">
                    <label for="soal">Pertanyaan:</label>
                    <textarea id="soal" name="soal" required></textarea>

                    <label for="pilihan_a">Pilihan A:</label>
                    <input type="text" id="pilihan_a" name="pilihan_a" required>

                    <label for="pilihan_b">Pilihan B:</label>
                    <input type="text" id="pilihan_b" name="pilihan_b" required>

                    <label for="pilihan_c">Pilihan C:</label>
                    <input type="text" id="pilihan_c" name="pilihan_c" required>

                    <label for="pilihan_d">Pilihan D:</label>
                    <input type="text" id="pilihan_d" name="pilihan_d" required>

                    <label for="jawaban_benar">Jawaban Benar:</label>
                    <select name="jawaban_benar" id="jawaban_benar" required>
                        <option value="">-- Pilih Jawaban --</option>
                        <option value="A">A</option>
                        <option value="B">B</option>
                        <option value="C">C</option>
                        <option value="D">D</option>
                    </select>

                    <button type="submit" class="btn btn-primary">Simpan Soal</button>
                </form>
            </div>
        </section>
    </main>

    <footer class="site-footer">
        <p>&copy; <?= date("Y") ?> Ujianku.com. Dibuat untuk latihan PHP Ujian Online.</p>
    </footer>
</body>
</html>
