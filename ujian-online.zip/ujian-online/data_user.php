<?php
session_start();
if (!isset($_SESSION['user']) || !isset($_SESSION['user']['role']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

include 'koneksi.php';
$users = mysqli_query($koneksi, "SELECT * FROM users");
if (!$users) {
    die("Gagal mengambil data user: " . mysqli_error($koneksi));
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Daftar User - UjianKu</title>
  <link rel="stylesheet" href="css/style.css" />
</head>
<body>
  <header class="header">
    <h1>Data Pengguna</h1>
    <nav>
      <a href="dashboard.php">Dashboard</a>
      <a href="kelola_soal.php">Soal</a>
      <a href="kelola_tes.php">Tes</a>
      <a href="data_user.php" class="active">User</a>
      <a href="logout.php">Logout</a>
    </nav>
  </header>

  <main class="container">
    <table class="tabel">
      <thead>
        <tr>
          <th>No</th>
          <th>Nama</th>
          <th>Username</th>
          <th>Role</th>
        </tr>
      </thead>
      <tbody>
        <?php $no = 1; while ($u = mysqli_fetch_assoc($users)): ?>
          <tr>
            <td><?= $no++ ?></td>
            <td><?= htmlspecialchars(isset($u['nama']) ? $u['nama'] : '') ?></td>
            <td><?= htmlspecialchars(isset($u['username']) ? $u['username'] : '') ?></td>
            <td><?= htmlspecialchars(ucfirst(isset($u['role']) ? $u['role'] : '')) ?></td>
          </tr>
        <?php endwhile; mysqli_close($koneksi); ?>
      </tbody>
    </table>
  </main>

  <footer class="footer">
    <p>&copy; <?= date('Y') ?> UjianKu</p>
  </footer>
</body>
</html>
