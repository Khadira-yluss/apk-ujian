<?php
session_start();
if (!isset($_SESSION['user']) || !isset($_SESSION['user']['role']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

include 'koneksi.php';
$dataTes = mysqli_query($koneksi, "SELECT * FROM tes");
if (!$dataTes) {
    die("Gagal mengambil data tes: " . mysqli_error($koneksi));
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Pengaturan Tes - UjianKu</title>
  <link rel="stylesheet" href="css/style.css" />
</head>
<body>
  <header class="header">
    <h1>Pengaturan Tes Ujian</h1>
    <nav>
      <a href="dashboard.php">Dashboard</a>
      <a href="kelola_soal.php">Kelola Soal</a>
      <a href="kelola_tes.php" class="active">Tes</a>
      <a href="data_user.php">User</a>
      <a href="logout.php">Logout</a>
    </nav>
  </header>

  <main class="container">
    <a href="tambah_tes.php" class="btn btn-primary">+ Tambah Tes</a>
    <table class="tabel">
      <thead>
        <tr>
          <th>No</th>
          <th>Nama Tes</th>
          <th>Jumlah Soal</th>
          <th>Durasi (menit)</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php $no = 1; while ($tes = mysqli_fetch_assoc($dataTes)): ?>
          <tr>
            <td><?= $no++ ?></td>
            <td><?= htmlspecialchars($tes['nama_tes'] ?? '') ?></td>
            <td><?= htmlspecialchars($tes['jumlah_soal'] ?? '') ?></td>
            <td><?= htmlspecialchars($tes['durasi'] ?? '') ?></td>
            <td>
              <a href="edit_tes.php?id=<?= urlencode($tes['id_tes'] ?? '') ?>" class="btn-edit">Edit</a>
              <a href="hapus_tes.php?id=<?= urlencode($tes['id_tes'] ?? '') ?>" class="btn-hapus" onclick="return confirm('Yakin hapus?')">Hapus</a>
            </td>
          </tr>
        <?php endwhile; mysqli_free_result($dataTes); mysqli_close($koneksi); ?>
      </tbody>
    </table>
  </main>

  <footer class="footer">
    <p>&copy; <?= date('Y') ?> UjianKu</p>
  </footer>
</body>
</html>
