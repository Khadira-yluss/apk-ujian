<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

$user = $_SESSION['user'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Dashboard | UjianKu</title>
  <link rel="stylesheet" href="css/style.css" />
</head>
<body>
  <header class="header">
    <h1>Selamat Datang, <?= htmlspecialchars(isset($user['nama']) ? $user['nama'] : 'Pengguna'); ?> 👋</h1>
    <nav>
      <a href="dashboard.php">Beranda</a>
      <?php if (isset($user['role']) && $user['role'] === 'admin'): ?>
        <a href="kelola_soal.php">Kelola Soal</a>
        <a href="kelola_tes.php">Kelola Tes</a>
        <a href="data_user.php">Data Siswa</a>
      <?php else: ?>
        <a href="soal.php">Mulai Ujian</a>
        <a href="hasil.php">Hasil Ujian</a>
      <?php endif; ?>
      <a href="logout.php">Logout</a>
    </nav>
  </header>

  <main class="dashboard">
    <?php if (isset($user['role']) && $user['role'] === 'admin'): ?>
      <section class="card-container">
        <?php
        include_once 'koneksi.php';
        // Jumlah Siswa
        $resSiswa = mysqli_query($koneksi, "SELECT COUNT(*) AS total FROM users WHERE role='siswa'");
        $totalSiswa = ($resSiswa && $row = mysqli_fetch_assoc($resSiswa)) ? $row['total'] : 0;
        // Jumlah Soal
        $resSoal = mysqli_query($koneksi, "SELECT COUNT(*) AS total FROM soal");
        $totalSoal = ($resSoal && $row = mysqli_fetch_assoc($resSoal)) ? $row['total'] : 0;
        // Jumlah Tes
        $resTes = mysqli_query($koneksi, "SELECT COUNT(*) AS total FROM tes");
        $totalTes = ($resTes && $row = mysqli_fetch_assoc($resTes)) ? $row['total'] : 0;
        // Tutup koneksi
        mysqli_close($koneksi);
        ?>
        <div class="card blue">
          <h3>Jumlah Siswa</h3>
          <p><?= $totalSiswa ?></p>
        </div>
        <div class="card purple">
          <h3>Jumlah Soal</h3>
          <p><?= $totalSoal ?></p>
        </div>
        <div class="card green">
          <h3>Jumlah Tes</h3>
          <p><?= $totalTes ?></p>
        </div>
      </section>
    <?php else: ?>
      <section class="welcome">
        <h2>Siap Ujian?</h2>
        <p>Silakan mulai tes yang tersedia dengan klik tombol di bawah.</p>
        <a href="soal.php" class="btn-ujian">Mulai Ujian</a>
      </section>
    <?php endif; ?>
  </main>

  <footer class="footer">
    <p>&copy; <?= date('Y') ?> UjianKu. Semua Hak Dilindungi.</p>
  </footer>
</body>
</html>
