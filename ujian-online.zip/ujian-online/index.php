<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>UjianKu - Platform Ujian Online</title>
    <link rel="stylesheet" href="css/style.css" />
</head>
<body class="site-wrapper">
<?php
session_start();
?>

<header>
    <div class="container">
        <h1>UjianKu</h1>
        <nav>
            <a href="index.php">Beranda</a>
            <a href="panduan.php">Panduan</a>
            <a href="dashboard.php">Dashboard</a>

            <?php if (isset($_SESSION['user'])): ?>
                <!-- Tampilkan hanya jika login -->
                <a href="profil_sekolah.php">Profil Sekolah</a>
                <a href="kelola_tes.php">Pengaturan Tes</a>
                <a href="data_user.php">Daftar User</a>
                <a href="logout.php">Keluar</a>
            <?php else: ?>
                <!-- Tampilkan jika belum login -->
                <a href="login.php">Masuk</a>
                <a href="register.php" class="daftar-btn">Daftar</a>
            <?php endif; ?>
        </nav>
    </div>
</header>

<main>
    <section class="hero">
        <div class="hero-content">
            <h2>Selamat Datang di <span>Ujian Online</span></h2>
            <p>Platform interaktif untuk mengasah kemampuanmu seperti <strong>Quizizz</strong> & <strong>Brain Academy</strong>.</p>
            <div class="hero-buttons">
                <?php if (isset($_SESSION['user'])): ?>
                    <!-- Tombol untuk admin/user login -->
                    <a href="profil_sekolah.php" class="btn btn-outline">Profil Sekolah</a>
                    <a href="kelola_tes.php" class="btn btn-outline">Pengaturan Tes</a>
                    <a href="data_user.php" class="btn btn-outline">Daftar User</a>
                <?php else: ?>
                    <!-- Tombol umum -->
                    <a href="login.php" class="btn btn-primary">Masuk Sekarang</a>
                    <a href="register.php" class="btn btn-outline">Daftar Akun Siswa</a>
                <?php endif; ?>
            </div>
        </div>
        <div class="hero-image">
            <img src="img/ujian-modern.png" alt="Ilustrasi Ujian" />
        </div>
    </section>
</main>

<footer class="site-footer">
    <p>&copy; <?= date("Y") ?> Ujianku.com. Dibuat untuk latihan PHP Ujian Online.</p>
</footer>
</body>
</html>
