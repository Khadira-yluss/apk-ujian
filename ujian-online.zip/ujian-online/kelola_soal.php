<?php
session_start();
if (!isset($_SESSION['user']) || !isset($_SESSION['user']['role']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

include 'koneksi.php';

// Tambah soal
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $pertanyaan = trim($_POST['pertanyaan'] ?? '');
    $pilihan_a = trim($_POST['pilihan_a'] ?? '');
    $pilihan_b = trim($_POST['pilihan_b'] ?? '');
    $pilihan_c = trim($_POST['pilihan_c'] ?? '');
    $pilihan_d = trim($_POST['pilihan_d'] ?? '');
    $jawaban_benar = trim($_POST['jawaban_benar'] ?? '');

    // Validasi sederhana
    if ($pertanyaan && $pilihan_a && $pilihan_b && $pilihan_c && $pilihan_d && in_array($jawaban_benar, ['A','B','C','D'])) {
        $sql = "INSERT INTO soal (pertanyaan, pilihan_a, pilihan_b, pilihan_c, pilihan_d, jawaban_benar)
                VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = mysqli_prepare($koneksi, $sql);
        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "ssssss", $pertanyaan, $pilihan_a, $pilihan_b, $pilihan_c, $pilihan_d, $jawaban_benar);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
        }
        header("Location: kelola_soal.php");
        exit();
    }
}

// Ambil semua soal
$soal_result = mysqli_query($koneksi, "SELECT * FROM soal ORDER BY id DESC");
if (!$soal_result) {
    die("Gagal mengambil data soal: " . mysqli_error($koneksi));
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <title>Kelola Soal | UjianKu</title>
  <link rel="stylesheet" href="css/style.css" />
</head>
<body>
  <header class="header">
    <h1>Kelola Soal</h1>
    <nav>
      <a href="dashboard.php">Dashboard</a>
      <a href="kelola_tes.php">Kelola Tes</a>
      <a href="data_user.php">Data Siswa</a>
      <a href="logout.php">Logout</a>
    </nav>
  </header>

  <main class="dashboard">
    <section class="card">
      <h2>Tambah Soal Baru</h2>
      <form method="POST" class="form-soal">
        <label>Pertanyaan:</label>
        <textarea name="pertanyaan" required></textarea>

        <label>Pilihan A:</label>
        <input type="text" name="pilihan_a" required />

        <label>Pilihan B:</label>
        <input type="text" name="pilihan_b" required />

        <label>Pilihan C:</label>
        <input type="text" name="pilihan_c" required />

        <label>Pilihan D:</label>
        <input type="text" name="pilihan_d" required />

        <label>Jawaban Benar:</label>
        <select name="jawaban_benar" required>
          <option value="">--Pilih Jawaban--</option>
          <option value="A">A</option>
          <option value="B">B</option>
          <option value="C">C</option>
          <option value="D">D</option>
        </select>

        <button type="submit">Simpan Soal</button>
      </form>
    </section>

    <section class="card">
      <h2>Daftar Soal</h2>
      <table class="tabel-soal">
        <thead>
          <tr>
            <th>No</th>
            <th>Pertanyaan</th>
            <th>Pilihan A</th>
            <th>B</th>
            <th>C</th>
            <th>D</th>
            <th>Jawaban</th>
          </tr>
        </thead>
        <tbody>
          <?php $no = 1; while ($soal = mysqli_fetch_assoc($soal_result)): ?>
          <tr>
            <td><?= $no++; ?></td>
            <td><?= htmlspecialchars($soal['pertanyaan'] ?? '') ?></td>
            <td><?= htmlspecialchars($soal['pilihan_a'] ?? '') ?></td>
            <td><?= htmlspecialchars($soal['pilihan_b'] ?? '') ?></td>
            <td><?= htmlspecialchars($soal['pilihan_c'] ?? '') ?></td>
            <td><?= htmlspecialchars($soal['pilihan_d'] ?? '') ?></td>
            <td><strong><?= htmlspecialchars($soal['jawaban_benar'] ?? '') ?></strong></td>
          </tr>
          <?php endwhile; mysqli_free_result($soal_result); mysqli_close($koneksi); ?>
        </tbody>
      </table>
    </section>
  </main>

  <footer class="footer">
    <p>&copy; <?= date('Y') ?> UjianKu. Semua Hak Dilindungi.</p>
  </footer>
</body>
</html>
