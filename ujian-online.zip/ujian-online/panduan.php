<?php
session_start();
require 'koneksi.php';

// Cek jika user belum login (konsisten dengan session yang lain)
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

// Ambil panduan dari database
$query = mysqli_query($koneksi, "SELECT isi FROM panduan LIMIT 1");
if (!$query) {
    $panduan = ['isi' => 'Panduan belum tersedia.'];
} else {
    $panduan = mysqli_fetch_assoc($query);
    if (!$panduan) {
        $panduan = ['isi' => 'Panduan belum tersedia.'];
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Panduan Ujian | UjianKu</title>
  <link rel="stylesheet" href="css/style.css">
  <style>
    .panduan-container {
      max-width: 800px;
      margin: 3rem auto;
      background: white;
      border-radius: 1rem;
      box-shadow: 0 0 20px rgba(0,0,0,0.1);
      padding: 2rem;
      color: #333;
    }

    .panduan-container h2 {
      color: #5a27c5;
      margin-bottom: 1rem;
      font-size: 2rem;
    }

    .panduan-container p {
      line-height: 1.7;
      font-size: 1.1rem;
    }

    .back-btn {
      display: inline-block;
      margin-top: 2rem;
      padding: 0.5rem 1rem;
      background-color: #5a27c5;
      color: white;
      text-decoration: none;
      border-radius: 0.5rem;
      transition: background 0.3s;
    }

    .back-btn:hover {
      background-color: #4522a2;
    }
  </style>
</head>
<body>
  <div class="panduan-container">
    <h2>Panduan Ujian</h2>
    <p><?= nl2br(htmlspecialchars($panduan['isi'])); ?></p>

    <a href="dashboard.php" class="back-btn">← Kembali ke Dashboard</a>
  </div>
</body>
</html>
