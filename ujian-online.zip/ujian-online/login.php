<?php
session_start();
include 'koneksi.php';

if (isset($_POST['login'])) {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    // Cek koneksi
    if (!$koneksi) {
        die("Koneksi gagal: " . mysqli_connect_error());
    }

    // Gunakan prepared statement untuk keamanan
    $stmt = mysqli_prepare($koneksi, "SELECT * FROM users WHERE email=?");
    mysqli_stmt_bind_param($stmt, "s", $email);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $data = mysqli_fetch_assoc($result);

    // Jika email ditemukan
    if ($data && password_verify($password, $data['password'])) {
        // Simpan seluruh data user ke session konsisten dengan file lain
        $_SESSION['user'] = [
            'id_user' => $data['id'],
            'nama' => $data['nama'],
            'role' => $data['role'],
            'email' => $data['email']
        ];
        mysqli_stmt_close($stmt);
        header("Location: index.php");
        exit;
    } else {
        $error = "Email atau Password salah!";
        if ($stmt) mysqli_stmt_close($stmt);
    }
}
?>


<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Login - UjianKu</title>
    <link rel="stylesheet" href="css\css.css">
</head>
<body class="login-page">
    <div class="login-container">
        <div class="login-card">
            <h2>Selamat Datang!</h2>
            <p>Masuk untuk mulai belajar seperti di Quizizz & Brain Academy</p>

            <?php if (isset($error)) echo "<div class='error'>$error</div>"; ?>

            <form method="POST">
                <input type="email" name="email" placeholder="Email" required>
                <input type="password" name="password" placeholder="Password" required>
                <button type="submit" name="login">Masuk</button>
            </form>

            <p class="link">Belum punya akun? <a href="register.php">Daftar Sekarang</a></p>
        </div>
        <div class="login-illustration">
            <img src="img/ilustrasi-login.png" alt="Ilustrasi Login">
        </div>
    </div>
</body>
</html>
