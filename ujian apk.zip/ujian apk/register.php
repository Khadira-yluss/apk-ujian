<?php
include 'inkoneksi.php';
$pesan = "";

if (isset($_POST['daftar'])) {
    $username     = $_POST['username'];
    $password     = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $nama         = $_POST['nama'];
    $nis          = $_POST['nis'];
    $kelas        = $_POST['kelas'];
    $email        = $_POST['email'];
    $alamat       = $_POST['alamat'];

    // Cek username sudah ada atau belum
    $cek = mysqli_query($koneksi, "SELECT * FROM users WHERE username='$username'");
    if (mysqli_num_rows($cek) > 0) {
        $pesan = "Username sudah digunakan!";
    } else {
        // Simpan ke tabel users
        $query_user = "INSERT INTO users (username, password, level, nama_lengkap) 
                       VALUES ('$username', '$password', 'siswa', '$nama')";
        $insert_user = mysqli_query($koneksi, $query_user);
        $id_user = mysqli_insert_id($koneksi); // Ambil ID terakhir

        // Simpan ke tabel siswa
        $query_siswa = "INSERT INTO siswa (id_user, nis, nama, kelas, email, alamat)
                        VALUES ('$id_user', '$nis', '$nama', '$kelas', '$email', '$alamat')";
        $insert_siswa = mysqli_query($koneksi, $query_siswa);

        if ($insert_user && $insert_siswa) {
            $pesan = "Registrasi berhasil. Silakan login.";
        } else {
            $pesan = "Terjadi kesalahan saat registrasi.";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Registrasi Siswa</title>
    <style>
        body {
            min-height: 100vh;
            margin: 0;
            font-family: 'Segoe UI', Arial, sans-serif;
            background: linear-gradient(135deg, #ff9800 0%, #43ea7a 100%);
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .register-container {
            background: rgba(255,255,255,0.95);
            border-radius: 18px;
            box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.18);
            padding: 40px 32px;
            width: 400px;
            text-align: center;
        }
        .register-container h2 {
            margin-bottom: 24px;
            color: #2e2e2e;
            font-weight: 700;
            letter-spacing: 1px;
        }
        .register-container label {
            display: block;
            text-align: left;
            margin-bottom: 6px;
            color: #555;
            font-size: 15px;
        }
        .register-container input[type="text"],
        .register-container input[type="password"],
        .register-container input[type="email"],
        .register-container textarea {
            width: 100%;
            padding: 10px 12px;
            margin-bottom: 18px;
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            font-size: 15px;
            background: #f9f9f9;
            transition: border 0.2s;
            resize: vertical;
        }
        .register-container input:focus,
        .register-container textarea:focus {
            border: 1.5px solid #43ea7a;
            outline: none;
        }
        .register-container button {
            width: 100%;
            padding: 12px;
            background: linear-gradient(90deg, #ff9800 60%, #43ea7a 100%);
            border: none;
            border-radius: 8px;
            color: #fff;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.2s;
        }
        .register-container button:hover {
            background: linear-gradient(90deg, #ff9800 40%, #43ea7a 100%);
        }
        .register-container p {
            margin-top: 12px;
            color: #e53935;
            font-weight: 500;
        }
        .register-container a {
            color: #43ea7a;
            text-decoration: none;
            font-weight: 600;
        }
        .register-container a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="register-container">
        <h2>Form Registrasi Siswa</h2>
        <?php if ($pesan) echo "<p>$pesan</p>"; ?>
        <form method="post">
            <label>Username:</label><br>
            <input type="text" name="username" required><br>

            <label>Password:</label><br>
            <input type="password" name="password" required><br>

            <label>Nama Lengkap:</label><br>
            <input type="text" name="nama" required><br>

            <label>NIS:</label><br>
            <input type="text" name="nis" required><br>

            <label>Kelas:</label><br>
            <input type="text" name="kelas" required><br>

            <label>Email:</label><br>
            <input type="email" name="email"><br>

            <label>Alamat:</label><br>
            <textarea name="alamat"></textarea><br><br>

            <button type="submit" name="daftar">Daftar</button>
        </form>

        <p>Sudah punya akun? <a href="login.php">Sign In di sini</a></p>
    </div>
</body>
<!--
</html>
