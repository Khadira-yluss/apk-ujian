<?php
session_start();
if ($_SESSION['level'] != 'admin') {
    header("Location: ../login.php");
    exit;
}
include 'inkoneksi.php';

if (isset($_POST['simpan'])) {
    $pertanyaan = $_POST['pertanyaan'];
    $a = $_POST['a'];
    $b = $_POST['b'];
    $c = $_POST['c'];
    $d = $_POST['d'];
    $jawaban = $_POST['jawaban'];

    mysqli_query($koneksi, "INSERT INTO soal (pertanyaan, opsi_a, opsi_b, opsi_c, opsi_d, jawaban_benar) 
    VALUES ('$pertanyaan', '$a', '$b', '$c', '$d', '$jawaban')");

    echo "<script>alert('Soal berhasil ditambahkan'); window.location='adminsoal_kelola.php';</script>";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Tambah Soal</title>
    <style>
        body {
            min-height: 100vh;
            margin: 0;
            font-family: 'Segoe UI', Arial, sans-serif;
            background: linear-gradient(135deg, #ff9800 0%, #43e97b 100%);
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .form-container {
            background: rgba(255,255,255,0.97);
            border-radius: 18px;
            box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.15);
            padding: 40px 32px;
            max-width: 500px;
            width: 100%;
            margin: 40px 0;
        }
        h2 {
            text-align: center;
            color: #2e2e2e;
            margin-bottom: 28px;
            font-weight: 700;
            letter-spacing: 1px;
        }
        label {
            font-weight: 500;
            color: #444;
            margin-bottom: 6px;
            display: block;
        }
        input[type="text"], textarea {
            width: 100%;
            padding: 10px 12px;
            margin-bottom: 18px;
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            background: #fafafa;
            font-size: 15px;
            transition: border 0.2s;
        }
        input[type="text"]:focus, textarea:focus {
            border: 1.5px solid #43e97b;
            outline: none;
            background: #fff;
        }
        textarea {
            min-height: 60px;
            resize: vertical;
        }
        button[type="submit"] {
            width: 100%;
            padding: 12px 0;
            background: linear-gradient(90deg, #ff9800 0%, #43e97b 100%);
            color: #fff;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            box-shadow: 0 2px 8px rgba(67, 233, 123, 0.08);
            transition: background 0.2s, transform 0.1s;
        }
        button[type="submit"]:hover {
            background: linear-gradient(90deg, #ffb347 0%, #38d39f 100%);
            transform: translateY(-2px) scale(1.02);
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Tambah Soal</h2>
        <form method="post">
            <label>Pertanyaan:</label><br>
            <textarea name="pertanyaan" rows="4" cols="50" required></textarea><br><br>

            <label>Opsi A:</label><br><input type="text" name="a" required><br>
            <label>Opsi B:</label><br><input type="text" name="b" required><br>
            <label>Opsi C:</label><br><input type="text" name="c" required><br>
            <label>Opsi D:</label><br><input type="text" name="d" required><br>

            <label>Jawaban Benar (A/B/C/D):</label><br>
            <input type="text" name="jawaban" maxlength="1" required><br><br>

            <button type="submit" name="simpan">Simpan</button>
        </form>
    </div>
</body>
</html>
