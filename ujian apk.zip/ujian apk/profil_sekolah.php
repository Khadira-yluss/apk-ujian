<?php
include 'inkoneksi.php';
$data = mysqli_query($koneksi, "SELECT * FROM profil_sekolah LIMIT 1");
$profil = mysqli_fetch_assoc($data);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Profil Sekolah</title>
    <style>
        body {
            min-height: 100vh;
            margin: 0;
            font-family: 'Segoe UI', Arial, sans-serif;
            background: linear-gradient(135deg, #ff9800 0%, #43e97b 100%);
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .profil-container {
            background: rgba(255,255,255,0.97);
            border-radius: 18px;
            box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.15);
            padding: 40px 32px;
            max-width: 600px;
            width: 100%;
            margin: 40px 0;
        }
        h2 {
            text-align: center;
            color: #2e2e2e;
            margin-bottom: 24px;
            font-weight: 700;
            letter-spacing: 1px;
        }
        p {
            color: #444;
            font-size: 16px;
            line-height: 1.7;
            margin: 10px 0;
        }
        strong {
            color: #ff9800;
        }
    </style>
</head>
<body>
    <div class="profil-container">
        <h2>Profil Sekolah</h2>
        <p><strong>Nama Sekolah:</strong> <?= $profil['nama_sekolah']; ?></p>
        <p><strong>Alamat:</strong> <?= $profil['alamat']; ?></p>
        <p><strong>Visi:</strong> <?= $profil['visi']; ?></p>
        <p><strong>Misi:</strong> <?= $profil['misi']; ?></p>
        <p><strong>Kontak:</strong> <?= $profil['kontak']; ?></p>
        <p><strong>Email:</strong> <?= $profil['email']; ?></p>
    </div>
</body>
</html>
