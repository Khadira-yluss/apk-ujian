<?php
session_start();
if ($_SESSION['level'] != 'admin') {
    header("Location: ../login.php");
    exit;
}
include 'inkoneksi.php';
// Hapus soal
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    mysqli_query($koneksi, "DELETE FROM soal WHERE id_soal=$id");
    echo "<script>alert('Soal berhasil dihapus'); window.location='adminsoal_kelola.php';</script>";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Kelola Soal</title>
      <style>
        body {
            min-height: 100vh;
            margin: 0;
            font-family: 'Segoe UI', Arial, sans-serif;
            background: linear-gradient(135deg, #ff9800 0%, #43e97b 100%);
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .container {
            background: rgba(255,255,255,0.97);
            border-radius: 18px;
            box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.15);
            padding: 40px 32px;
            max-width: 1100px;
            width: 100%;
            margin: 40px 0;
        }
        h2 {
            text-align: center;
            color: #2e2e2e;
            margin-bottom: 28px;
            font-weight: 700;
            letter-spacing: 1px;
        }
        a {
            display: inline-block;
            margin-bottom: 18px;
            padding: 10px 18px;
            background: linear-gradient(90deg, #ff9800 0%, #43e97b 100%);
            color: #fff;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            transition: background 0.2s, transform 0.1s;
        }
        a:hover {
            background: linear-gradient(90deg, #ffb347 0%, #38d39f 100%);
            transform: translateY(-2px) scale(1.02);
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background: #fff;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(67, 233, 123, 0.08);
        }
        th, td {
            padding: 12px 10px;
            text-align: left;
        }
        th {
            background: #43e97b;
            color: #fff;
            font-weight: 600;
        }
        tr:nth-child(even) {
            background: #f7f7f7;
        }
        tr:hover {
            background: #e0ffe6;
        }
        td a {
            background: none;
            color: #ff9800;
            padding: 0;
            margin: 0 4px;
            border-radius: 0;
            font-weight: 600;
        }
        td a:hover {
            color: #43e97b;
            background: none;
            text-decoration: underline;
            transform: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Daftar Soal</h2>
        <a href="adminsoal_tambah.php">+ Tambah Soal</a>
        <table>
            <tr>
                <th>No</th>
                <th>Pertanyaan</th>
                <th>Opsi A</th>
                <th>Opsi B</th>
                <th>Opsi C</th>
                <th>Opsi D</th>
                <th>Jawaban</th>
                <th>Aksi</th>
            </tr>
            <?php
            $no = 1;
            $data = mysqli_query($koneksi, "SELECT * FROM soal");
            while ($row = mysqli_fetch_assoc($data)) {
            ?>
            <tr>
                <td><?= $no++; ?></td>
                <td><?= $row['pertanyaan']; ?></td>
                <td><?= $row['opsi_a']; ?></td>
                <td><?= $row['opsi_b']; ?></td>
                <td><?= $row['opsi_c']; ?></td>
                <td><?= $row['opsi_d']; ?></td>
                <td><?= $row['jawaban_benar']; ?></td>
                <td>
                    <a href="adminsoal_edit.php?id=<?= $row['id_soal']; ?>">Edit</a> |
                    <a href="?hapus=<?= $row['id_soal']; ?>" onclick="return confirm('Yakin ingin menghapus?')">Hapus</a>
                </td>
            </tr>
            <?php } ?>
        </table>
    </div>
</body>
</html>
