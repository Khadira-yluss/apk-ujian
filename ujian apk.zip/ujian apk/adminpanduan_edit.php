<?php
session_start();
if ($_SESSION['level'] != 'admin') {
    header("Location: ../login.php");
    exit;
}
include 'inkoneksi.php';;

$data = mysqli_query($koneksi, "SELECT * FROM panduan_ujian LIMIT 1");
$isi = mysqli_fetch_assoc($data);

if (isset($_POST['simpan'])) {
    $judul = $_POST['judul'];
    $text  = $_POST['isi'];

    $update = mysqli_query($koneksi, "UPDATE panduan_ujian SET judul='$judul', isi='$text' WHERE id=" . $isi['id']);

    if ($update) {
        echo "<script>alert('Panduan berhasil diperbarui');window.location.href='adminpanduan_edit.php';</script>";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Panduan Ujian</title>
    <style>
        body {
            min-height: 100vh;
            margin: 0;
            font-family: 'Segoe UI', Arial, sans-serif;
            background: linear-gradient(135deg, #ff9800 0%, #43e97b 100%);
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .edit-container {
            background: rgba(255,255,255,0.95);
            border-radius: 18px;
            box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.15);
            padding: 40px 32px;
            max-width: 500px;
            width: 100%;
            margin: 40px 0;
        }
        h2 {
            text-align: center;
            color: #2e2e2e;
            margin-bottom: 28px;
            font-weight: 700;
            letter-spacing: 1px;
        }
        label {
            font-weight: 500;
            color: #444;
            margin-bottom: 6px;
            display: block;
        }
        input[type="text"], textarea {
            width: 100%;
            padding: 10px 12px;
            margin-bottom: 18px;
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            background: #fafafa;
            font-size: 15px;
            transition: border 0.2s;
        }
        input[type="text"]:focus, textarea:focus {
            border: 1.5px solid #43e97b;
            outline: none;
            background: #fff;
        }
        textarea {
            min-height: 120px;
            resize: vertical;
        }
        button[type="submit"] {
            width: 100%;
            padding: 12px 0;
            background: linear-gradient(90deg, #ff9800 0%, #43e97b 100%);
            color: #fff;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            box-shadow: 0 2px 8px rgba(67, 233, 123, 0.08);
            transition: background 0.2s, transform 0.1s;
        }
        button[type="submit"]:hover {
            background: linear-gradient(90deg, #ffb347 0%, #38d39f 100%);
            transform: translateY(-2px) scale(1.02);
        }
    </style>
</head>
<body>
    <div class="edit-container">
        <h2>Edit Panduan Ujian</h2>
        <form method="post">
            <label>Judul:</label>
            <input type="text" name="judul" value="<?= $isi['judul']; ?>">

            <label>Isi Panduan:</label>
            <textarea name="isi" rows="10"><?= $isi['isi']; ?></textarea>

            <button type="submit" name="simpan">Simpan Panduan</button>
        </form>
    </div>
</body>
</html>
