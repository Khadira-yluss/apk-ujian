<?php
session_start();
if ($_SESSION['level'] != 'admin') {
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Dashboard Admin</title>
    <style>
        body {
            min-height: 100vh;
            margin: 0;
            font-family: 'Segoe UI', Arial, sans-serif;
            background: linear-gradient(135deg, #ff9800 0%, #43e97b 100%);
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .dashboard-container {
            background: rgba(255,255,255,0.97);
            border-radius: 18px;
            box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.15);
            padding: 40px 32px;
            max-width: 400px;
            width: 100%;
            margin: 40px 0;
            text-align: center;
        }
        h2 {
            color: #2e2e2e;
            margin-bottom: 18px;
            font-weight: 700;
            letter-spacing: 1px;
        }
        .welcome {
            font-size: 18px;
            color: #444;
            margin-bottom: 28px;
        }
        a {
            display: inline-block;
            margin-top: 12px;
            padding: 10px 24px;
            background: linear-gradient(90deg, #ff9800 0%, #43e97b 100%);
            color: #fff;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            transition: background 0.2s, transform 0.1s;
        }
        a:hover {
            background: linear-gradient(90deg, #ffb347 0%, #38d39f 100%);
            transform: translateY(-2px) scale(1.02);
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <h2>Dashboard Admin</h2>
        <div class="welcome">
            Selamat datang Admin, <?= $_SESSION['username']; ?>
        </div>
        <a href="logout.php">Logout</a>
    </div>
</body>
</html>


