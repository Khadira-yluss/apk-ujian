<?php
session_start();
include 'inkoneksi.php';

if (isset($_POST['login'])) {
    $username = mysqli_real_escape_string($koneksi, $_POST['username']);
    $password = $_POST['password'];

    // Cek user
    $query = "SELECT * FROM users WHERE username='$username'";
    $result = mysqli_query($koneksi, $query);
    $data = mysqli_fetch_assoc($result);

    if ($data && password_verify($password, $data['password'])) {
        $_SESSION['id'] = $data['id'];
        $_SESSION['username'] = $data['username'];
        $_SESSION['level'] = $data['level'];

        // Redirect berdasarkan level
        if ($data['level'] == 'admin') {
            header("Location: dashboard_admin.php");
            exit;
        } elseif ($data['level'] == 'guru') {
            header("Location: dashboard_guru.php");
            exit;
        } elseif ($data['level'] == 'siswa') {
            header("Location: dashboard_siswa.php");
            exit;
        }
    } else {
        $error = "Username atau password salah.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login Ujian Online</title>
    <style>
        body {
            min-height: 100vh;
            margin: 0;
            font-family: 'Segoe UI', Arial, sans-serif;
            background: linear-gradient(135deg, #ff9800 0%, #43ea7a 100%);
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .login-container {
            background: rgba(255,255,255,0.95);
            border-radius: 18px;
            box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.18);
            padding: 40px 32px;
            width: 350px;
            text-align: center;
        }
        .login-container h2 {
            margin-bottom: 24px;
            color: #2e2e2e;
            font-weight: 700;
            letter-spacing: 1px;
        }
        .login-container label {
            display: block;
            text-align: left;
            margin-bottom: 6px;
            color: #555;
            font-size: 15px;
        }
        .login-container input[type="text"],
        .login-container input[type="password"] {
            width: 100%;
            padding: 10px 12px;
            margin-bottom: 18px;
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            font-size: 15px;
            background: #f9f9f9;
            transition: border 0.2s;
        }
        .login-container input:focus {
            border: 1.5px solid #43ea7a;
            outline: none;
        }
        .login-container button {
            width: 100%;
            padding: 12px;
            background: linear-gradient(90deg, #ff9800 60%, #43ea7a 100%);
            border: none;
            border-radius: 8px;
            color: #fff;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.2s;
        }
        .login-container button:hover {
            background: linear-gradient(90deg, #ff9800 40%, #43ea7a 100%);
        }
        .login-container p {
            margin-top: 12px;
            color: #e53935;
            font-weight: 500;
        }
        .login-container a {
            color: #43ea7a;
            text-decoration: none;
            font-weight: 600;
        }
        .login-container a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h2>Login Ujian Online</h2>
        <?php if (isset($error)) echo "<p>$error</p>"; ?>
        <form method="post">
            <label>Username:</label>
            <input type="text" name="username" required>

            <label>Password:</label>
            <input type="password" name="password" required>

            <button type="submit" name="login">Login</button>
        </form>
        <p>Belum punya akun? <a href="register.php">Sign Up di sini</a></p>
    </div>
</body>
</html>
